# MoodJournal

A Django-based mood tracking and journaling web application with a minimalist pastel UI design, mood analytics, and personalized content recommendations.

## Features

- **User Authentication**: Register, login, and logout functionality
- **Mood Tracking**: Log your daily mood (happy, excited, calm, neutral, tired, anxious, sad, angry)
- **Journaling**: Write and store daily journal entries
- **Mood Analytics**: Visualize your mood trends over time with interactive charts
- **Personalized Content**: Get tailored music, activities, and journal prompts based on your mood
- **Responsive Design**: Works on desktop and mobile devices

## Tech Stack

- **Backend**: Django
- **Database**: PostgreSQL
- **Frontend**: HTML, CSS, JavaScript, Bootstrap
- **Charts**: Chart.js
- **Icons**: Font Awesome

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/moodjournal.git
cd moodjournal
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables (create a `.env` file in the root directory):
```
SECRET_KEY=your_secret_key
DATABASE_URL=postgres://user:password@localhost:5432/moodjournal
DEBUG=True
```

5. Run migrations:
```bash
python manage.py makemigrations
python manage.py migrate
```

6. Create a superuser:
```bash
python manage.py createsuperuser
```

7. Run the development server:
```bash
python manage.py runserver
```

8. Open your browser and navigate to http://localhost:8000

## Screenshots

![Home Page](screenshots/home.png)
![Mood Analytics](screenshots/analytics.png)
![Personalized Content](screenshots/recommendations.png)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.